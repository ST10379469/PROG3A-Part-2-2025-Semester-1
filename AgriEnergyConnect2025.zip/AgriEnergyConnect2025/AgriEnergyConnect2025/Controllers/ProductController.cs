﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AgriEnergyConnect2025.Data;
using AgriEnergyConnect2025.Models;
using System.Linq;
using System.Threading.Tasks;

namespace AgriEnergyConnect2025.Controllers
{
    [Authorize]
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProductController(ApplicationDbContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Farmer")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Farmer")]
        public async Task<IActionResult> Create(Product product)
        {
            if (ModelState.IsValid)
            {
                var farmer = await _context.Farmers.FirstOrDefaultAsync(f => f.Email == User.Identity.Name);
                if (farmer != null)
                {
                    product.FarmerId = farmer.Id;
                    _context.Add(product);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Index", "Home");
                }
            }
            return View(product);
        }

        [Authorize(Roles = "Employee")]
        public async Task<IActionResult> List(int? farmerId, string productType, DateTime? startDate, DateTime? endDate)
        {
            var products = _context.Products.Include(p => p.Farmer).AsQueryable();

            if (farmerId.HasValue)
            {
                products = products.Where(p => p.FarmerId == farmerId.Value);
            }

            if (!string.IsNullOrEmpty(productType))
            {
                products = products.Where(p => p.Category == productType);
            }

            if (startDate.HasValue)
            {
                products = products.Where(p => p.ProductionDate >= startDate.Value);
            }

            if (endDate.HasValue)
            {
                products = products.Where(p => p.ProductionDate <= endDate.Value);
            }

            ViewBag.Farmers = await _context.Farmers.ToListAsync();
            return View(await products.ToListAsync());
        }
    }
}